#include "AddOnSerialBase.h"

AddOnSerialBase::AddOnSerialBase(SC16IS750 *expander, byte dtrPort) {
  m_logItemCallback = nullptr;
  m_expander = expander;
  m_dtrPort = dtrPort;
  m_doLogging = false;
}

void AddOnSerialBase::SetLogItemCallback(LogItemCallbackType callback) {
  m_logItemCallback = callback;
}

void AddOnSerialBase::Begin() {
  m_expander->PinMode(m_dtrPort, OUTPUT);
  m_expander->DigitalWrite(m_dtrPort, HIGH);
}

void AddOnSerialBase::SetBaudrate(unsigned long baudrate) {
  m_expander->SetBaudrate(baudrate);
}

void AddOnSerialBase::Log(String text, bool newLine) {
  if (m_doLogging) {
    m_log += text + (newLine ? "\n" : "");
    if (m_logItemCallback) {
      m_logItemCallback(text, newLine);
    }
  }
}

void AddOnSerialBase::Reset() {
  m_expander->DigitalWrite(m_dtrPort, LOW);
  delay(50);
  m_expander->DigitalWrite(m_dtrPort, HIGH);
}


