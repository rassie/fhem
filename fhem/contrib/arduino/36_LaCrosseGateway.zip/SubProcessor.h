#ifndef _SUBPROCESSOR_H
#define _SUBPROCESSOR_H

#include "AddOnSerialBase.h"
#include "ESP8266WebServer.h"
#include "FS.h"

class SubProcessor : public AddOnSerialBase {
public:
  SubProcessor(SC16IS750 *expander, byte dtrPort);
  void Begin(ESP8266WebServer *server);
  void Handle();
  bool HasReceivedData();
  String GetReceivedData();
 
private:
  ESP8266WebServer *m_server;
  File m_uploadFile;
  word m_currentPage;
  unsigned long m_originalBaudRate;
  String m_receivedData;
  String m_dispatchData;
  void FlashFile(File *file);
  void BeginFlash();
  void SendFile(File *file);
  void FinishFlash();
  void SendBytes(byte count, ...);
  void SendBytes(byte count, byte *data);
  void Receive();
  void SendPage(byte packet[128], byte size);
};


#endif

